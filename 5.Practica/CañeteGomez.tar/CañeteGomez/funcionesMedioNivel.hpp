#ifndef FUNCIONES_MEDIO_NIVEL
#define FUNCIONES_MEDIO_NIVEL

void obtenerCiclosHamiltonianos();
void viajanteComercioOptimoSinPoda();
void viajanteComercioOptimoConPoda();
void nReinasBacktracking();
void nReinasLasVegas();
void nReinasLasVegasTodas();

#endif
